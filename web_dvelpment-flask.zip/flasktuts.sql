-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 26, 2021 at 05:25 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `flasktuts`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `serial` int(50) NOT NULL,
  `Name` text NOT NULL,
  `email` varchar(50) NOT NULL,
  `number` int(50) NOT NULL,
  `msg` text NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`serial`, `Name`, `email`, `number`, `msg`, `date`) VALUES
(1, 'example 1', 'random@gmail.com', 1535759546, 'inserting first value in database in sqlalchemy in flask', '2021-12-18 18:27:53'),
(2, 'Abhishek Prajapati', 'username_1@gmail.com', 1535759546, 'let\'s check either it\'s going to work or note', '2021-12-18 19:13:45'),
(3, 'Abhishek Prajapati', 'username_1@gmail.com', 1236547895, 'testing', '2021-12-19 11:28:48'),
(4, 'Abhishek Prajapati', 'username_1@gmail.com', 1236547895, 'testing', '2021-12-19 11:30:07'),
(5, 'Abhishek Prajapati', 'username_1@gmail.com', 2147483647, 'testing', '2021-12-19 11:37:01'),
(6, 'Abhishek Prajapati', 'username_1@gmail.com', 2147483647, 'testing', '2021-12-19 11:43:21'),
(7, 'Abhishek Prajapati', 'username_1@gmail.com', 2147483647, 'this going to be send on my inbox-', '2021-12-19 17:44:44');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `serial` int(50) NOT NULL,
  `title` text NOT NULL,
  `slug` varchar(25) NOT NULL,
  `content` text NOT NULL,
  `each_bg` varchar(25) NOT NULL,
  `Date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`serial`, `title`, `slug`, `content`, `each_bg`, `Date`) VALUES
(1, 'this my first title for my first post', 'first-post', 'This post data is fetched from database using python and flask and its working, wow!', 'assets/img/post-bg.jpg', '2021-12-21 21:06:08'),
(2, 'This is going to  be a second post', 'sec-post', 'after this tutorial i am going to make a website which some kind of cheating site for students where they can write there assignment digital but it shows like written by manually means written by hand. ', '', '2021-12-22 12:59:43'),
(3, 'Third Post', 'th-post', 'this is the third post', '', '2021-12-22 23:14:54'),
(4, 'Fourth Post', 'frth-post', 'this is the fourth post from your blog', '', '2021-12-22 23:14:54'),
(5, 'Fifth Post', 'fifth-post', 'this is fifth post added from admin panel, this is fun', 'imgbg.png', '2021-12-24 13:03:34'),
(6, 'Sixth Post', 'sixth-post', 'Sorry, this must be sixth post added from admin panel, this is fun', 'imgbg.png', '2021-12-24 13:06:35'),
(7, 'Seventh Post', 'seventh-post', 'as  i said i am going to edit this post form admin panel, i am going to edit this post using admin panel', 'imgbg.png', '2021-12-24 17:24:59'),
(11, 'Eighth Post', 'eighth-post', 'i am editing this post, i am inserting 8th post for fun', 'imgbg.png', '2021-12-24 19:45:08'),
(12, 'Twelveth  Post', '12th-post', 'i am inserting 12th post for fun', 'imgbg.png', '2021-12-24 19:49:40');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`serial`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`serial`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `serial` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `serial` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
