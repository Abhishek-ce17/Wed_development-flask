from flask import Flask, render_template, request, session, redirect
from flask_sqlalchemy import SQLAlchemy
from flask_mail import Mail
from werkzeug.utils import secure_filename
from datetime import datetime
import json as j
import math
import os


with open('config.json', 'r') as c:
    params = j.load(c)["params"]

app = Flask(__name__)
app.secret_key = 'super-secret-key'
app.config['UPLOAD_FILE'] = params['file_location']
app.config.update( 
    MAIL_SERVER = 'smtp.gmail.com',
    MAIL_PORT = '465',
    MAIL_USE_SSL = True,
    MAIL_USERNAME = params['gmail-user'],
    MAIL_PASSWORD = params['gmail-pass']
    )

mail = Mail(app)
app.config['SQLALCHEMY_DATABASE_URI'] = params['uri']
db = SQLAlchemy(app)

class Contact(db.Model):
    serial = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), unique=False, nullable=False)
    email = db.Column(db.String(20), nullable=False)
    number = db.Column(db.String(120), nullable=False)
    msg = db.Column(db.String(120), nullable=False)
    date = db.Column(db.String(12))

class Posts(db.Model):
    serial = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(80), unique=False, nullable=False)
    slug = db.Column(db.String(25), nullable=False)
    content = db.Column(db.String(120), nullable=False)
    each_bg = db.Column(db.String(120), nullable=False)
    date = db.Column(db.String(12))

@app.route("/")
def home():
    posts = Posts.query.filter_by().all()
    last = math.ceil(len(posts)/int(params['post_num']))
    #pagination logic
    page = request.args.get('page')
    if(not str(page).isnumeric()):
        page = 1
    page = int(page)
    posts = posts[(page-1)*int(params['post_num']) : (page-1)*int(params['post_num'])+int(params['post_num'])]
    if(page == 1):
        prev = "#"
        next = "/?page=" + str(page+1)
    elif(page == last):
        next = "#"
        prev = "/?page=" + str(page-1)
    else:
        next = "/?page=" + str(page+1)
        prev = "/?page=" + str(page-1)
    return render_template("index.html", params = params, posts = posts, prev = prev, next = next)

@app.route("/admin-login", methods = ["GET","POST"])
def dashboard():
    if 'user' in session and session['user'] == params['admin_name']:
        post = Posts.query.all()
        return render_template('admin-panel.html', params=params, posts = post)
    if request.method == 'POST':
        username = request.form.get('uname')
        userpass = request.form.get('upass')
        if (username == params['admin_name'] and userpass == params['admin_pass']):
            #set the session variable
            post = Posts.query.all()
            session['user'] = username
        return render_template('admin-panel.html', params=params, posts=post)
    return render_template("sign-in.html", params = params)

@app.route("/edit/<string:serial>", methods = ['GET', 'POST'])
def edit(serial):
    if 'user' in session and session['user'] == params['admin_name']:
        if request.method == 'POST':
            new_title = request.form.get('title')
            new_slug = request.form.get('slug')
            new_content = request.form.get('content')
            new_bg_img = request.form.get('imgbg')
            if serial == '0':
                post = Posts(title = new_title, slug = new_slug, content = new_content, each_bg = new_bg_img, date = datetime.now())
                db.session.add(post)
                db.session.commit()
            else:
                post = Posts.query.filter_by(serial = serial).first()
                post.title = new_title
                post.slug = new_slug
                post.content = new_content
                post.each_bg = new_bg_img
                post.datetime = datetime.now()
                db.session.commit()
                return redirect('/edit/'+serial)
        post = Posts.query.filter_by(serial = serial).first()
        return render_template('edit.html', params = params, serial = serial, post = post)

@app.route("/upload-file", methods = ["GET","POST"])
def upload():
    if 'user' in session and session['user'] == params['admin_name']:
        if (request.method == "POST"):
            f = request.files["ch-file"]
            f.save(os.path.join(app.config['UPLOAD_FILE'], secure_filename(f.filename)))
            return "uploaded succesfully"

@app.route("/about")
def about():
    return render_template("about.html", params = params)

@app.route("/post/<string:post_slug>", methods = ["GET"])
def blog_post(post_slug):
    post = Posts.query.filter_by(slug = post_slug).first()
    return render_template("post.html", params = params, post = post)

@app.route("/logout")
def logout():
    session.pop('user')
    return redirect('/')

@app.route("/delete/<string:serial>", methods = ['GET', 'POST'])
def delete(serial):
    if 'user' in session and session['user'] == params['admin_name']:
        post = Posts.query.filter_by(serial = serial).first()
        db.session.delete(post)
        db.session.commit()
    return redirect('/admin-login')

@app.route("/contact", methods=["GET","POST"])
def contact():
    if(request.method == 'POST'):
        name = request.form.get('name')
        email = request.form.get('email')
        numb = request.form.get('number')
        mess = request.form.get('msg')
        entry = Contact(name = name, email = email, number = numb, msg = mess, date = datetime.now())
        db.session.add(entry)
        db.session.commit()
        mail.send_message('new message from ' + name, 
                            sender = email, 
                            recipients = [params['gmail-user']],
                            body = mess +"\n"+ numb) 

    return render_template("contact.html", params = params)
@app.route("/post")
def post():
    return render_template("post.html", params = params)
app.run(debug = True)  #dont need reload after doign any changes             